﻿define config.default_textshader='typewriter'

define y = Character(" [name]", color= "#b00d0d")
define l = Character('Linnea', color="#29d129")
define ra = Character('Rainer', color="#4b94e3")
define sa = Character('Sakura', color="#ba63d5")
define re = Character('Rea', color="#8deeed")
define p = Character('Pyro', color="#f7500f")
define sp = Character('Sparky', color="#f9f33f")
define t = Character('Tamao', color="#898686")
define k = Character('Kira', color='#fc9ee5')
define f = Character('Eva', color='#ffffff')
define u = Character('???', color="#AAAAAA")
define n = Character('Violet', color= "#6428d4")  
define a = Character('LMENG_', color="#ff66c7")
define i = Character('Izzy', color = '#66c2ff')
define e = Character('{glitch=80}Eva{/glitch}')
define yg = Character(" {glitch=80}[name]{/glitch}", color= "#b00d0d")

image Tamao = "Tamao.png"
image Kira = "Kira.png"

python:
    custom_tags = ["omega", "bt", "fi", "sc", "rotat", "chaos", "move", "glitch"]


label start: 
    $ eva = 0
    $ eevee = False
    $ amie = False
    $ apple = 0
    $ weird = 0
    $ goodbye = 0
    $ glitch = False
    $ quick_menu = False
    $ _backing = False
    scene black with fade


    "The ecocomy has been suffering."
    "No one was willing to hire you."
    "No one was willing to hire a poor student."
    "But at last, you've found a job as a cashier in a local supermarket."
    with dissolve
    pause 1.0
    python:
        name = renpy.input("What is your name? (Type below)")

        name = name.strip() or "You"

    if name == "You":
        $ glitch = True

    if name == "Eva":
        $ eevee = True
    if name == "eva":
        $ eevee = True

    elif name == "Aki Mitsumi":
        $ amie = True
    if name == "aki mitsumi":
        $ amie = True
    if name == "Aki mitsumi":
        $ amie = True
    if name == "aki Mitsumi":
        $ amie = True

    show text "Day 1" at truecenter
    with dissolve
    pause 2.0
    hide text
    with dissolve
    $ quick_menu = True
    scene checkout2
    show linnea at left
    l "Hello..."
    "She reads your name tag."
    l "[name]"
    y "Hello."
    y "..."
    "Such healthy food."
    "Spinach, celery, carrots-"
    "BROCCOLI" with hpunch
    "Ew ew ew ew ew ew ew ew ew" with hpunch
    "But no time to waste on criticising other people's foods. You have a job to do."
    "You scan Linnea's grocery items."
    pause 1.0
    hide linnea
    "*Ding ding ding*"
    "Someone enters the supermarket."
    show eva at left
    u "Things that are healthy do not last for long."
    u "..."
    "She holds a singular red apple in her hands."
    menu:
        "Ask her to leave":
            y "Hey uh, could you please leave the store?"
            $ eva = 1.0
            $ goodbye = 1
            u "..."
            "She leaves the apple in your hands."
            hide eva
            " " with hpunch
            "The broken door slams on her way out."
            show linnea at left
            "You turn to Linnea."
            y "Your total comes to $14.57"
            "Linnea pays."
            l "Thanks, have a nice day."
            "You remember the mysterious person."
            hide linnea
            jump day1

        "Ask her to wait":
            $ apple = 1
            y "Hey uh, could you please wait your turn?"
            "She nods and moves behind Linnea."
            hide eva
            show linnea at left
            pause 1
            y "Your total comes to $14.57"
            "Linnea pays."
            l "Thanks, have a nice day."
            "You smile at her as she leaves."
            hide linnea
            show eva at left
            "The mysterious person is looking at you."
            y "Can I help you now?"
            u "I would like this apple."
            y "Your total is $0.75"
            "She hands you $1 and turns to leave."
            hide eva
            y "Wait, your change..."
            y "She's already gone..."
            jump day1

    label day1:
        "...."
        "...."
        "...."
        "...."
        y "It's time to close up the store."
        "You close up the store."
        pause 2.0
        scene black
        "You go home."
        menu:
            "Sleep":
                "Tired out from the day, you sleep immediately."
                jump day2
            "Wonder if asking mysterious person to leave was a bad idea" if eva == 1: 
                y "I wonder if she had a purpose..."
                "You fall asleep wondering about the mysterious person, hoping she'll be back."
                jump day2
    label day2:
        show text "Day 2" at truecenter
        with dissolve
        pause 2.0
        hide text
        with dissolve
        scene checkout2
        "This is your 2nd day working in the supermarket."
        "Don't get fired."
        "*Ding ding ding*"
        show eva at left
        y "Already..?"
        menu:
            "It's you again":
                "You greet the mysterious person."
                if goodbye == 1:
                    u "You turned me away yesterday..."
                    menu:
                        "Apologize":
                            y "Sorry..."
                            u "..."
                        "...":
                            y "...."
                            u "...."

                "She holds a singular apple again."
                y "What's your name?"
                u "My name?"
                y "After all, you know mine."
                if eevee == True:
                    "... Eva, the same as yours."
                elif eevee == False:
                    u "... [name]"
                    u "..."
                    f "Eva."
                elif amie == True:
                    u "... Akiko."
                    y "H-how did you?"
                    f "My name is Eva"
                    f "And I will be your person from now on."
                f "She gives you the apple and turns to leave."
                y "Wait!"
                hide eva
                " " with hpunch
                y "She's gone..."
                jump rainer

            "It's you again....":
                if eva == 0:
                    $ eva = 1
                elif eva == 1:
                    $ eva = 2
                "You turn to look at the mysterious person."
                y "It's you again, what do you want?"
                if goodbye == 1:
                    u "You turned me away yesterday..."
                    menu:
                        "Apologize":
                            y "Sorry..."
                            u "..."
                        "...":
                            y "...."
                            u "...."

                "She holds a singular apple again."
                y "Are you going to talk today?"
                u "Your name is [name]?"
                y "Yes."
                if eevee == True:
                    f "My name is Eva, the same as yours."
                elif eevee == False:
                    f "My name is Eva."
                y "Anything else?"
                f "No"
                y "Okay, well, please leave the store, you're disturbing others."
                "The store is empty apart from you and her."
                "She looks around, hands you the apple and turns to leave."
                hide eva
                " " with hpunch
                y "Finally."
                jump rainer
    label rainer: 
        "Someone appears at the checkout."
        show rainer at left
        ra "..."
        ra "Hello."
        y "Hi!"
        "You scan Rainer's grocery items."
        "Strawberries, lettuce, peaches..."
        "Water??"
        y "Well hydration is key to life I guess."
        ra "Huh?"
        y "Nothing."
        y "Your total comes to $18.65"
        "Slightly more than yesterday's earnings."
        "He did buy expensive strawberries after all."
        ra "Thank you-"
        ra "Hey, did you see that person outside?"
        menu:
            "What person?":
                ra "Nevermind."
                ra "She's weird."
                menu:
                    "Don't say that!":
                        ra "Sorry sorry."
                    "Yeah...":
                        $ weird = 1
                        y "Yeah..."
                        ra "..."
            "Yes":
                y "Yeah, why?"
                ra "She seemed weird."
                menu:
                    "Don't say that!":
                        ra "Sorry sorry"
                    "Yeah...":
                        $ weird = 1
                        y "Yeah..."
                        ra "..."
            "No":
                ra "Nevermind."
                ra "She's weird"
                menu:
                    "Don't say that!":
                        ra "Sorry sorry"
                    "Yeah...":
                        $ weird = 1
                        y "Yeah..."
                        ra "..."
        if eevee == True:
            ra "Her name is Eva, the same as yours."
            ra "..."
        ra "Thanks, I'll be going now."
        y "Would you like your-"
        hide rainer
        " " with hpunch
        y "receipt..?"
        pause 1.0
        y "What's with people leaving before I finish my sentences...?"
        "...."
        "...."
        "It's time to close up the store."
        "Well, closing time."
        scene black
        "You go home and sleep again."
        pause 1.0
        jump day3

    label day3:
        show text "Day 3" at truecenter
        with dissolve
        pause 2.0
        hide text
        with dissolve
        scene checkout2
        "Third day..."
        "*Ding ding ding*"
        show eva at left
        y "Again-"
        if weird == 1:
            f "You called me weird yesterday."
            menu:
                "No I didn't":
                    if eva == 0:
                        $ eva = 1
                    elif eva == 1:
                        $ eva = 2
                    elif eva == 2:
                        $ eva = 3
                    y "I did not."
                    f "Liar"
                "...":
                    y "..."
                    f "..."
                "How would you know?":
                    f "I just know."
                    f "This isn't a game you know."
                    f "This town has secrets..."
                    y "..."
        y "..."
        y "Just- how may I assist you today?"
        f "I want another apple."
        y "That's $0.75"
        if apple == 0:
            $ apple = 1
        if apple == 1:
            $ apple = 2
        "She hands you another dollar."
        y "Your change?"
        f "Keep it."
        y "Okay..."
        "She leaves."
        hide eva
        "...."
        "...."
        "...."
        "...."
        "...."
        show sakura at left
        sa "H-hi."
        y "Hello, how can I help you?"
        sa "I-"
        sa "I buy things."
        "You resist the urge to slam your head down on the counter. Of course you're a supermarket employee. You SCAN PEOPLE'S GROCERIES."
        y "Right, sorry."
        "You hurry to scan her items."
        "Freeze dried raspberries.."
        y "Didn't know we sold those, are they good?"
        sa "Yes, you can put them in salads and with yogurt..."
        "Cornflakes and chocolate milk"
        y "Huh, do you eat cereal with flavored milk?"
        sa "Normal milk is boring..."
        hide sakura
        f "But flavored milk is more unhealthy."
        show eva at left
        y "I THOUGHT YOU LEFT!!!!" with hpunch
        f "Ultra processed foods brought me back."
        menu:
            "GET OUT!!!!":
                y "GET OUT OF THE STORE!!"
                if eva == 0:
                    $ eva = 1
                elif eva == 1:
                    $ eva = 2
                elif eva == 2:
                    $ eva = 3
                elif eva == 3:
                    $ eva = 4

                if goodbye == 0:
                    $ goodbye = 1
                elif goodbye == 1:
                    $ goodbye = 2
                f "Sorry sorry, I'll go!!"
                hide eva
                " " with hpunch
            "Why are you here again":
                f "The UPFs brought me back."
                y "Okay, but can you leave poor Miss Sakura alone?"
                f "But cornflakes and chocolate milk is insane!!"
                menu:
                    "Kick her out":
                        if goodbye == 0:
                            $ goodbye = 1
                        elif goodbye == 1:
                            $ goodbye = 2
                        y "Sorry Eva, but you've gotta go."
                        f "THE UPFS!!!!!"
                        hide eva
                        " " with hpunch
        show sakura at left
        y "Sorry about that."
        y "Your total is $12.60"
        sa "That was-"
        if goodbye == 1:
            show eva at right
            f "HOW DARE YOU KICK ME OUT!!!"
            f "YOU CAN'T HIDE FROM THE ULTRA PROCESSED FOODS SAKURA!!!!!" with hpunch
            f "I'll be back for you, [name]..."
        if goodbye == 2:
            show eva at right
            f "HOW DARE YOU KICK ME OUT TWICE!!!"
            f "YOU CAN'T HIDE FROM THE ULTRA PROCESSED FOODS SAKURA!!!!!" with hpunch
            f "I'll be back for you, [name]..."
        sa "-concerning"
        hide eva
        y "Oops..."
        "Sakura leaves the store after paying."
        hide sakura

        scene black
        "You go home, extremely tired from throwing Eva out the store."
        y "Ughhh that was tiring."
        jump day4
    label day4:
        show text "Day 4" at truecenter
        with dissolve
        pause 2.0
        hide text
        with dissolve
        scene checkout2
        "This is your fourth day working at the supermarket."
        y "There'd better be more people today..."
        y "..."
        y "Or some rich person who has money to spend on groceries."
        "*Ding ding ding*"
        if eva > 2:
            y "Not again..."
        else:
            y "Her again?"
        show rea at left
        y "It's not Eva..."
        y "Hi."
        re "Hey [name]"
        "You scan Rea's grocery items."
        "Cake roll, cheese, milk and ham?"
        "That sounds like a problem for lactose intolerant people."
        y "You really like dairy items."
        re "Heheh, yeah. The ham is for my pet cat."
        y "Aww, a cat!"
        re "Yeah!! I accidentally left him in the freezer the other day."
        y "What"
        re "Heheheheheheh"
        y "Your total comes to $18.90"
        "Rea pays."
        re "Thanks for doing this service after the last employee disappeared..."
        menu:
            "You're welcome!":
                y "Hah, you're welcome!!"
                re "..."
            "What":
                y "Disappeared?"
                re "Oops, did the owner not tell you?"
                y "NO??????"
                re "Oh well."
                re "You didn't hear that from me."
        "He leaves."
        hide rea
        y "Disappeared..."
        y "Interesting..."
        "..."
        y "It's closing time already."
        "You close the store."
        scene black
        menu:
            "Continue":
                y "I need the money..."
                "You continue the job."
            "Quit the job":
                y "I need the money."
                y "I can't leave now."
                y "But all of them..."
                y "The missing employee."
                y "This everchanging economy."
                menu:
                    "Leave":
                        y "I really need to go."
                        y "But..."
                        y "How would I pay for all my expenses..."
                        y "Food is so expensive nowadays."
                        "Final Chance..."
                        menu:
                            "Leave":
                                y "I'll find a way."
                                "You leave and try to get another job. A fast food employee, perhaps?"
                                "Goodness knows how long it'll take for you to earn enough money to live comfortably."
                                f "Good things never come for free."
                                f "Your freedom always came at a price."
                                return
                            "Stay":
                                y "I need to survive this."

                    "Stay":
                        y "I need to survive this economy."
        "You close your eyes, ready for another day of supermarket suffering."
        y "Please... Let someone buy lots and lots of food..."
        y "Don't let me..."
        y "Disappear..."
        if eevee == True:
            y "And the other Eva"
            y "Who is she?"
            y "Why does she keep visiting me?"
        with dissolve
        pause 0.5

        show text "Day 5" at truecenter
        with dissolve
        pause 2.0
        hide text
        with dissolve
        scene checkout2
        y "5th day."
        y "How about... I leave after 2 days."
        y "Employment for 7 days."
        y "Wonderful."
        show pyro normal at left
        p "Hi."
        y "Hi."
        p "Your name is [name]?"
        y "Does it say so on my name tag?"
        p "Yes."
        y "Well done, that's my name."
        p "I know.."
        "You scan Pyro's items."
        "Chorizo"
        "Cream cheese and ricotta stuffed bell peppers"
        "Kimchi"
        "Spicy Ice Cream?"
        y "This is quite a lot."
        p "I'm a successful dentist."
        y "Dentists eating marinated food, ice cream and sausages??"
        hide pyro normal
        show pyro eyes at left
        p "...."
        hide pyro eyes
        show pyro normal at left
        y "Your total is $25.49"
        "He gives you the money."
        y "Thanks."
        p "I hope you survive longer than Violet did."
        y "Who?"
        p "..."
        hide pyro normal
        show pyro eyes at left
        p "Nevermind."
        hide pyro eyes
        " " with hpunch
        " " with hpunch
        " " with hpunch
        " " with hpunch
        y "Goodbye?"
        y "Who is Violet?.."
        f "Vi is none of your business."
        show eva at left
        menu:
            "Interrogate":
                if eva == 0:
                    $ eva
                elif eva == 1:
                    $ eva
                elif eva:
                    $ eva = 3
                elif eva == 3:
                    $ eva = 4
                elif eva == 4:
                    $ eva == 5
                y "Who is she?"
                f "No one."
                y "Who??" with hpunch
                f "..."
                " " with hpunch
            "Ask":
                y "What?"
                f "Violet."
                f "Leave her."
                y "Why-?"
                f "LEAVE HER."
                y "OKAY OKAY"
                f "An apple."
                y "$0.80 cents"
                if apple == 0:
                    $ apple = 1 
                elif apple == 1:
                    $ apple = 2
                elif apple == 2:
                    $ apple = 3
                f "..."
                f "Goodbye."
        hide eva
        " " with hpunch
        y "Just close the store at this point."
        "You close the store."
        scene black
        pause 2.0
        show text "01:43 AM" at truecenter
        with dissolve
        pause 2.0
        hide text
        with dissolve
        y "..."
        y "I can't sleep."
        y "Who is Violet?"
        y "How did she disappear?"
        "..."
        "You're going to get fired if you don't show up on time. Sleep soon."
        pause 3.0
        jump day6

    label day6:
        show text "Day 6" at truecenter
        with dissolve
        pause 2.0
        hide text
        with dissolve
        scene checkout2
        y "Only one more day until I tell my employer I'm leaving."
        y "Given no one comes for me today."
        y "Or tomorrow..."
        show sparky1 at left
        sp "Hi, are you a worker here?"
        y "Yes."
        sp "Here are my items."
        "You scan his items."
        "Pineapple juice"
        y "Is this...Soda?"
        sp "Juice"
        "*ding ding ding*"
        hide sparky1
        show eva at left
        f "Doesn't make it much healthier."
        y "Why are you back?"
        f "UPF's brought me back"
        y "..."
        menu:
            "Bargain":
                y "If I don't kick you out then will you tell me about Violet?"
                if weird == 1:
                    f "You called me weird."
                if goodbye == 2:
                    f "You turned me out..."
                    f "Twice"
                    y "..."
                if eevee == True:
                    f "Soon, my friend, my name buddy"
                elif eevee == False:
                    f "No."
            "Say hi":
                y "Hi?"
                f "Hi."
                y "Can I ask you about Violet?"
                if weird == 1:
                    f "You called me weird."
                if goodbye == 2:
                    f "You turned me out..."
                    f "Twice."
                    y "..."
                if eevee == True:
                    f "Soon, my friend, my name buddy"
                elif eevee == False:
                    f "No."
        y "Okay..."
        hide eva
        " " with hpunch
        show sparky1 at left
        y "Uh."
        "Lemon mochi"
        y "That would stick to my teeth."
        sp "Heheh"
        "That's not a lot of food..."
        "The economy is getting worse."
        sp "..."
        y "Uh-"
        y "Sorry!!"
        y "Your total comes to $12.47"
        sp "..."
        "He hands you his money."
        hide sparky1
        " " with hpunch
        y "Bye..."
        y "No one else is coming today."
        scene black
        y "This economy..."
        y "It's alright."
        y "One more day."
        pause 2.0
    show text "{color=#ff0000}Day 7{/color}" at truecenter
    with dissolve
    pause 2.0
    hide text
    with dissolve
    scene checkout2
    show Tamao at left
    t "Hi."
    y "Hello!"
    t "Here-"
    "You scan Tamao's items."
    "Let's see..."
    "Chocolate mud cake (with extra buttercream frosting) chocolate doughnuts, and burnt basque cheesecake (chocolate flavoured)."
    "This girl really likes chocolate, huh?"
    y "Sweet tooth?"
    t "None of your business. What's wrong with indulging in some treats once in a while?"
    y "I didn't mean it that way, sorry."
    t "It's fine. My items, please."
    "You realise your hands had stopped moving after the conversation, and you scramble to pick up the pace."
    y "Your total cost comes to $57.18"
    t "..Was it always that high? I could've sworn these wouldn't have cost that much a few years back."
    y "Well, I'm afraid I have no control over these matters. You enjoy your choc binge through."
    "She's already walking away."
    t "I wonder if this situation would get worse with coming days.."
    "She mutters the sentence under her breath as she leaves, desserts in tow."
    hide Tamao

    "Returning your gaze to the checkout queue, you get ready for the next customer."
    
    show Kira at left
    k "Hiya! How are you, [name]?"
    y "I'm doing quite well, thanks."
    k "That's good to hear; here you go."
    "She places down a pack of frozen tempura and instant noodles."
    "YUM!!!!"
    "You try not to let the hunger seep through your perfect employee smile."
    y "That'll be $10.58 in total."
    k "Not bad for a single meal. That's my new record, y'know?"
    y "Excuse me?"
    k "I challenge myself to order the cheapest meals I can at supermarkets. It's quite the fun for me and my wallet."
    k "However, recently it's somehow been harder to get under my budget."
    k "..Until now! Another win for Kira!"
    y "That sounds interesting."
    y "Good luck with your shopping!"
    hide Kira
    "Kira drags out a long 'Thank youuuuu' all the way to the parking lot."
    "*Ding ding ding*"
    y "It's her again?"
    y "Eva?"
    show eva at left
    if eva == 5:
        f "Why do you seem to hate me?"
    if eevee == True:
        f "I'm Eva. You're Eva."
        f "Maybe we were {color=#ff0000}{i}meant to be {/i}{/color}"
        y "..."
        menu:
            "Yes":
                y "Maybe we were."
                f "So, do you want to destory this economy with me?"
                menu:
                    "Yes":
                        y "Let's do it."
                        scene black
                        "You run away to destroy the economy with Eva"
                        "{color=#ff0000} Ending: {i}Eva {/i}{/color}"
                        return

                    "No":
                        y "I'm sorry."
                        f "But-" 
                        y "..."
                        f "..."
                        jump no

            "No":
                y "No we were not."
                f "But-"
                y "I'm sorry."
                jump no           
    elif amie == True:
        jump yuri
    jump no

    label no:
        f "I'll be going now."
        if eevee == 1:
            y "..."
            y "I'm sorry."
            "She walks towards you."
            scene black
            " " with hpunch
            "She threw an apple at you and pushed you to the ground."
            "Ending: Murdered by Eva"
            jump credits
        y "But you just came."
        f "..."
        hide eva
        " " with hpunch
        show violet normal with dissolve
        n "Hi."
        y "Ah!"
        n "Sorry; did I scare you?"
        n "I'm Violet, I was caprtured by a gingerbread man a while ago..."
        scene empty
        pause 0.8
        scene checkout2
        show violet normal
        y "Great..."
        n "Avoid UPFs okay? Did you realise how more and more snuck in and prices went up?"
        menu:
            "Yes":
                n "Good job."
            "No":
                hide violet normal
                show violet pissed
                n "Stupid..."
                n "Why would you do that..."
                hide violet pissed
                show violet normal
                n "Well, let it serve as a lesson, then."
                n "Try to be more perceptive next time, okay? The real world isn't as kind."
                hide violet normal with dissolve
                "Ending: Not avoiding UPFs"
                return
        y "..."
        y "I'll avoid UPFs then, seeing as you got kidnapped by a gingerbread man."
        hide violet with dissolve
        n "Thank you."
        "Ending: Avoiding UPFs"

        return

label yuri:
    f "Your name is Aki Mitsumi."
    f "My name is-"
    pause 1.0
    hide eva
    show text "{glitch=100}{image=eva.png}{/glitch}" at left  
    pause 0.5
    scene black
    y "I really {swap=love@hate@0.24}love{/swap} doing this."
    u "Maybe we were...{glitch=30}{color=#fab1d7}{i}meant to be {/i}{/color}{/glitch}"
 
    
    
    scene black
    a "{color=#fab1d7}...Aki Mitsumi?{/color}"
    a "{color=#fab1d7}My name is LMENG_, as you can probably see from my name on the top left {/color}"
    a "{color=#fab1d7}This was made for a 2026 STEAM Project at Westlake Girls High School {/color}"
    a "{color=#fab1d7}Hope you enjoyed <3{/color}"
    hi"{color=#fab1d7}Hey! Don't forget me too! :333{/color}"
    $ quick_menu = False
    show text "{glitch=30}{color=#fab1d7}Secret End{/color}{/glitch}" at truecenter
    with dissolve
    pause 1.0
    hide text with fade
    jump yuricredits




label credits:
   
    $ _skipping = False
    $ renpy.choice_for_skipping()
    
    $ quick_menu = False
    scene black with fade
    show text "End" at truecenter
    with dissolve
    $ renpy.pause(2.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Code and story by he-re438 & LMENG_ as part of STEAM 11" at truecenter
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Special thanks to all that helped with inspiration and playtesting" at truecenter
    with dissolve
    $ renpy.pause(1.0, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard= True)
    show text "Thank you to all that helped share ideas to shape this visual novel" at truecenter
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Created for STEAM Innovation Project 2026" at truecenter
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Thank you for playing" at truecenter
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    with dissolve
    return

label yuricredits:
    $ _skipping = False
    $ renpy.choice_for_skipping()

    $ renpy.pause(1.0, hard=True)
    show text "Code and story by he-re438 & LMENG_ as part of STEAM 11" at truecenter
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Special thanks to all that helped with inspiration and playtesting" at truecenter
    with dissolve
    $ renpy.pause(1.0, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard= True)
    show text "Thank you to all that helped share ideas to shape this visual novel" at truecenter
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Created for STEAM Innovation Project 2026" at truecenter
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    show text "Thank you for playing" at truecenter
    with dissolve
    $ renpy.pause(1.5, hard=True)
    hide text with fade
    $ renpy.pause(1.0, hard=True)
    with dissolve
    return
   







        

